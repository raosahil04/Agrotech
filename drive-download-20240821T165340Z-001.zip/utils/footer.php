<hr class = "footerline"><!--css modified horizontal line-->
<footer>
    <div class = "container">
        <div class = "row">
            <section>
                <div class = "footerContent col-md-4"><!--left content-->
                    <p class = "footerContent1">
                        <strong>J</strong><span class = "small footerSubtext">AYPEE</span>
                        <strong>Y</strong><span class = "small footerSubtext">OUTH</span>
                        <strong>C</strong><span class = "small footerSubtext">LUB</span>
                    </p>

                    <!-- <p class = "footerSubtext2">
                        Kill Avenue, Dun Laoghaire, Co. Dublin
                        &copy; Urban Events Venue & Catering, 2016.
                    </p> -->
                </div>
            </section>
            <section>
                <div class = "footcontent col-md-4"><!--middle content-->
                    Set your goals high,<br>
                    and don't stop till you get there.<br>
                </div>
            </section>
            <section>
                <div class = "footcontent col-md-4"><!--right content-->
                    Follow Us:<br>
                        <img src = "images/facebook.png">
                        <img src = "images/twitter.png">
                        <img src = "images/googleplus.png">
                        <img src = "images/youtube.png">
                </div>
            </section>
        </div>
    </div>
</footer>